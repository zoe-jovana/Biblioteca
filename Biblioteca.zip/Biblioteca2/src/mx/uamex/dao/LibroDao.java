package mx.uamex.dao;

import java.util.ArrayList;
import java.util.List;
import mx.uamex.dto.Alumno;
import mx.uamex.dto.Libro;

public class LibroDao {
      List<Libro> libros = new ArrayList<Libro>();
    Integer id=0;
    
    public void agregarLibro(Libro libro){
        libro.setId(id+1);
        id++;
        
    }
   // 
    public void actualizarLibro (Libro libro) {
      for (int i = 0; i < libros.size(); i++) {
          if(libros.get(i).getId()== libro.getId()){
              libros.get(i).setNombre(libro.getNombre());
              libros.get(i).setEditorial(libro.getEditorial());
              libros.get(i).setStock(libro.getStock());
//               alumnos.get(i).setApellidoMaterno(alumno.getApellidoMaterno());
          }
            }     
    }
    //
    public void eliminarLibro(Libro libro){
        libros.remove (libro);
        
    }
    ////
    public void imprimirLibro (ArrayList<Libro> lista){
       for (int i = 0; i < lista.size(); i++) {
           System.out.println(lista.get(i).toString());
       
        }  
    }
    ////
    
   public Libro buscarLibro(int id) {
        for (int i = 0; i < libros.size(); i++) {
            Libro a= libros.get(i);
            if(a.getId()== id ){
                 return a;
            }
        }
         return null; 
    }
    
}
