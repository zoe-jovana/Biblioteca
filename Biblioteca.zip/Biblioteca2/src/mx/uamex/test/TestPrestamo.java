/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mx.uamex.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import mx.uamex.dto.Alumno;
import mx.uamex.dto.Libro;
import mx.uamex.dto.Prestamo;
import mx.uamex.dto.Persona;
import mx.uamex.dto.Profesor;


import mx.uamex.dao.AlumnoDao;
import mx.uamex.dao.ProfesorDao;
import mx.uamex.dao.LibroDao;
import mx.uamex.dao.PrestamoDao;

/**
 *
 * @author Angela Rios
 */
public class TestPrestamo {

    public static void main(String[] args) {

//        Persona personita = new Persona();
//        personita.getClass();
//        System.out.println(personita);
        Libro libro1 = new Libro();
        libro1.setId(1);
        libro1.setNombre("Fundamentos de programacion");
        libro1.setCategoria("Programación");
        libro1.setEditorial("Alfaomega");
        libro1.setIsbn(2324);
        libro1.setStock(5);

        Libro libro2 = new Libro();
        libro2.setId(1);
        libro2.setNombre("Calculo");
        libro2.setCategoria("Matematicas");
        libro2.setEditorial("Alfaomega");
        libro2.setIsbn(344);
        libro2.setStock(2);

        List<Libro> listaLibros = new ArrayList<>();
        listaLibros.add(libro1);
        listaLibros.add(libro2);

        Alumno alumno1 = new Alumno();
        alumno1.setId(1);
        alumno1.setNombre("Diego");
        alumno1.setApellidoPaterno("Hernadez");
        alumno1.setApellidoMaterno("Ruiz");
        alumno1.setNumeroCuenta(20227102);

        System.out.println("Persona{" + "id=" + alumno1.getId() + ", nombre=" + alumno1.getNombre() + ", apellidoPaterno=" + alumno1.getApellidoPaterno() + ", apellidoMaterno=" + alumno1.getApellidoMaterno() + ", genero=" + alumno1.getGenero() + '}');System.out.println();
        
        Prestamo prestamo1 = new Prestamo();
        Date fechaIni = new Date();
        prestamo1.setId(1);
        prestamo1.setFolio(234);
        prestamo1.setFechainicio(fechaIni);
        prestamo1.setLibros(listaLibros);
        prestamo1.setPersona(alumno1);
        
        System.out.println(prestamo1);
        System.out.println("");
        System.out.println("");
        System.out.println("");
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        Libro libro3 = new Libro();
        libro3.setId(4);
        libro3.setNombre("Calculo 2");
        libro3.setCategoria("Matematicas");
        libro3.setEditorial("Alfaomega");
        libro3.setIsbn(8392);
        libro3.setStock(3);

        Libro libro4 = new Libro();
        libro4.setId(3);
        libro4.setNombre("Quimica");
        libro4.setCategoria("Ciensia");
        libro4.setEditorial("Lumbreras");
        libro4.setIsbn(344);
        libro4.setStock(4);

        Alumno alumno2 = new Alumno();
        alumno2.setId(2);
        alumno2.setNombre("Zoe");
        alumno2.setApellidoPaterno("Meraz");
        alumno2.setApellidoMaterno("Ramírez");
        alumno2.setNumeroCuenta(1916795);
        
        System.out.println("Persona{" + "id=" + alumno2.getId() + ", nombre=" + alumno2.getNombre() + ", apellidoPaterno=" + alumno2.getApellidoPaterno() + ", apellidoMaterno=" + alumno2.getApellidoMaterno() + ", genero=" + alumno2.getGenero() + '}');System.out.println();
        
        List<Libro> listaLibros2 = new ArrayList<>();
        listaLibros2.add(libro3);
        listaLibros2.add(libro4);

        Prestamo prestamo2 = new Prestamo();
        Date fechaIni2 = new Date();
        prestamo2.setId(2);
        prestamo2.setFolio(321);
        prestamo2.setFechainicio(fechaIni2);
        prestamo2.setLibros(listaLibros2);
        prestamo2.setPersona(alumno2);
        
        System.out.println(prestamo2);
         System.out.println("");
        System.out.println("");
        System.out.println("");
         ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        Libro libro5 = new Libro();
        libro5.setId(2);
        libro5.setNombre("Arte");
        libro5.setCategoria("Arte");
        libro5.setEditorial("Castillo");
        libro5.setIsbn(4920);
        libro5.setStock(2);

        Libro libro6 = new Libro();
        libro6.setId(4);
        libro6.setNombre("Ecuaciones lineales");
        libro6.setCategoria("Matematicas");
        libro6.setEditorial("Alfaomega");
        libro6.setIsbn(3443);
        libro6.setStock(2);

        Alumno alumno3 = new Alumno();
        alumno3.setId(3);
        alumno3.setNombre("Suni");
        alumno3.setApellidoPaterno("Miranda");
        alumno3.setApellidoMaterno("Garcia");
        alumno3.setNumeroCuenta(2218938);
        
        System.out.println("Persona{" + "id=" + alumno3.getId() + ", nombre=" + alumno3.getNombre() + ", apellidoPaterno=" + alumno3.getApellidoPaterno() + ", apellidoMaterno=" + alumno3.getApellidoMaterno() + ", genero=" + alumno3.getGenero() + '}');System.out.println();
        
        List<Libro> listaLibros3 = new ArrayList<>();
        listaLibros2.add(libro5);
        listaLibros2.add(libro6);

        Prestamo prestamo3 = new Prestamo();
        Date fechaIni3 = new Date();
        prestamo3.setId(3);
        prestamo3.setFolio(840);
        prestamo3.setFechainicio(fechaIni3);
        prestamo3.setLibros(listaLibros3);
        prestamo3.setPersona(alumno2);
        
        System.out.println(prestamo3);
    }
}
